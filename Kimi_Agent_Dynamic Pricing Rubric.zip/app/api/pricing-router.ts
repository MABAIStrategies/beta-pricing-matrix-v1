import { z } from "zod";
import { and, asc, desc, eq } from "drizzle-orm";
import { getDb } from "./queries/connection";
import { proposals, rateFactors, services } from "../db/schema";
import { authedQuery, createRouter, publicQuery } from "./middleware";

export const catalogRouter = createRouter({
  rateFactors: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(rateFactors)
      .orderBy(asc(rateFactors.category), asc(rateFactors.sortOrder));
  }),
  services: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(services).orderBy(asc(services.sortOrder));
  }),
});

const proposalInput = z.object({
  name: z.string().min(1).max(255),
  clientName: z.string().max(255).optional(),
  inputs: z.record(z.string(), z.string()),
  lineItems: z.array(z.record(z.string(), z.unknown())),
  totals: z.record(z.string(), z.number()),
});

export const proposalsRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select()
      .from(proposals)
      .where(eq(proposals.userId, ctx.user.id))
      .orderBy(desc(proposals.createdAt));
  }),
  create: authedQuery.input(proposalInput).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const [result] = await db.insert(proposals).values({
      userId: ctx.user.id,
      name: input.name,
      clientName: input.clientName ?? null,
      inputs: input.inputs,
      lineItems: input.lineItems,
      totals: input.totals,
    });
    return { id: result.insertId };
  }),
  remove: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .delete(proposals)
        .where(and(eq(proposals.id, input.id), eq(proposals.userId, ctx.user.id)));
      return { ok: true };
    }),
});
