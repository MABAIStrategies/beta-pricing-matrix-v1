import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { catalogRouter, proposalsRouter } from "./pricing-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  catalog: catalogRouter,
  proposals: proposalsRouter,
});

export type AppRouter = typeof appRouter;
